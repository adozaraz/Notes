# Infinitive as the subject
- As the subject, the infinitive can go at the beginning of the sentence.
**Ex:** `To ride with the drunk driver is dangerous.`
- The sentence may also start with the introductory `it` as a formal subject. These formal subject is not translated into russian and we can easily rewrite the sentence to express the same idea without introductory `it`. 
**Ex:** `It's essential to get a visa = To get a visa is essential`
- Infinitive in the Interrogative is always found in introductory `it`
**Ex**: `Is it difficult to operate this machine?`

# Infinitive as the Predicative
- The infinitive can be used as the Predicative and in this case (`The weather (Subject) is nice (Predicate)`), the infinitive follows the link verb. (Link v + inf)
**Ex**: `My wish (subject) is to go (predicate) round the world.`
- If the predicative of the sentence consists of an adjective and an infinitive, the infinitive is called *the secondary predicative* (Link v + adj + inf)
**Ex**: `This story (subject) is *easy to believe* (predicative)`
- The infinitive can be the secondary predicative only in sentences where the subject is notional (условный)
**Ex**: `At first, our new boss was pleasant to deal with.` - Secondary predicative
# Infinitive as the purpose
- Used to tell why an action is performed.
**Ex**: `It came here to study English`